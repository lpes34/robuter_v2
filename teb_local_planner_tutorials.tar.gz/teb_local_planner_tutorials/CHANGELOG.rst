^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package teb_local_planner_tutorials
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.1 (2016-11-15)
------------------
* Default parameters updated
* Navigation run-dependencies added

0.2.0 (2016-05-23)
------------------
* Added example setup for an omnidirectionl robot (ROS kinetic+)
* Run-dependency removed: metapackage navigation


0.0.2 (2016-04-18)
------------------
* This is a minor release due to the final releases for Saucy, Utopic and Vivid.
* Deprecated parameters are removed from the config in order to avoid warnings each time the planner is initialized.
* A costmap conversion example is now included.

0.0.1 (2016-04-14)
------------------
* Initial release with two stage simulation examples (diffdrive and carlike robots) and all tutorial scripts.

